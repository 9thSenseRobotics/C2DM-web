-- phpMyAdmin SQL Dump
-- version 3.3.10.4
-- http://www.phpmyadmin.net
--
-- Host: mysql.abarry.org
-- Generation Time: Jan 02, 2012 at 01:33 AM
-- Server version: 5.1.53
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `telo`
--
CREATE DATABASE `telo` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `telo`;

-- --------------------------------------------------------

--
-- Table structure for table `phones`
--

CREATE TABLE IF NOT EXISTS `phones` (
  `name` text NOT NULL,
  `deviceid` text NOT NULL,
  `registration` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `phones`
--

INSERT INTO `phones` (`name`, `deviceid`, `registration`) VALUES
('Andy''s phone', '22a10000135615cb', 'APA91bEsX9uBGKVAWuxLFqzaRGR-pFT5FvIwUBUI1QjPbliL-NvOmZjp8XMxxrSpxTQNo_roVFkKSBY2YKS4YFKWmZLtCILspsqYXpsk8ae-bpFJrqzWB2iKE5tF1Tr0HTuGpnJXPXT2ppvGPz4YO9pdech2oAUokw');
